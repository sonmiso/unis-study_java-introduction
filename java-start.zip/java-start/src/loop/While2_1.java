package loop;

public class While2_1 {

    public static void main(String[] args) {
        int sum = 0;

        sum = sum + 1;
        System.out.println("i = " + 1 + " sum = " + sum);

        sum = sum + 2;
        System.out.println("i = " + 2 + " sum = " + sum);

        sum = sum + 3;
        System.out.println("i = " + 3 + " sum = " + sum);

    }
}
