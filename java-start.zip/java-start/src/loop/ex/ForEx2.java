package loop.ex;

public class ForEx2 {

    public static void main(String[] args) {
        //이 버전을 추천. 번잡함.
        /*int num = 2;
        for (int i = 1; i <= 10; i++) {
            System.out.println(num);
            num += 2;
        }
         */

        //여러가지 쓸 수 있음
        for (int num = 2, count = 1; count <= 10; num += 2, count++) {
            System.out.println(num);
        }
    }
}
