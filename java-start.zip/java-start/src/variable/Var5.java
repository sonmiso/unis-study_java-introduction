package variable;

public class Var5 {
    public static void main(String[] args) {
        int a;
        a = 1;
        System.out.println(a);

        int b = 2;
        System.out.println(b);

        int c = 3, d = 4;
        System.out.println(c);
        System.out.println(d);
    }
}
