package variable;

public class Var8 {
    public static void main(String[] args) {
        //정수
        byte b = 127; //-128 ~ 127
        short s = 32767;
        int i = 2147483647;
        long l = 9223372036854775807L; //int 이상(대략 20억 이상)일 경우 뒤에 'L' 붙여야함.

        //실수
        float f = 10.0f; //기본은 double. 뒤에 f 붙여야 함
        double d = 10.0;
    }
}
