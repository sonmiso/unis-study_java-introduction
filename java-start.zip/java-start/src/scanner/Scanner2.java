package scanner;

public class Scanner2 {

    public static void main(String[] args) {

    }
}
