package operator.ex;

public class OperationEx3 {

    public static void main(String[] args) {
        int score = 80;
        boolean result =  80 <= score && score <= 100;
        System.out.println(result);
    }
}
