package variable;

public class Var2 {
    public static void main(String[] args) {
        int a; //변수 선언
        a = 20; //10 - > 20

        System.out.println(a);
        System.out.println(a);
        System.out.println(a);
    }
}
