package variable;

public class Var6 {

    public static void main(String[] args) {
        int a;
        //System.out.println(a);
    }
}
